import{a as t}from"../chunks/entry.BE8bQzum.js";export{t as start};
