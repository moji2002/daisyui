import{a as t}from"../chunks/entry.CliODqVY.js";export{t as start};
